plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.offlinehomeworkai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.offlinehomeworkai"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}

dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
}
