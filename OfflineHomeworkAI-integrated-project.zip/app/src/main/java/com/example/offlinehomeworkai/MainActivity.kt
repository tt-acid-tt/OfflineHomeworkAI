package com.example.offlinehomeworkai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.text.InputType
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val purple = Color.rgb(103, 80, 164)
    private val executor = Executors.newSingleThreadExecutor()
    private var selectedImage: Uri? = null
    private var modelPath: String? = null
    private var engine: Engine? = null
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null
    private lateinit var status: TextView
    private lateinit var memoryValue: TextView
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private lateinit var memorySeek: SeekBar
    private lateinit var modelButton: Button
    private var memoryGb = 2.5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memoryGb = getPreferences(0).getFloat("memory_gb", 2.5f).toDouble()
        modelPath = File(filesDir, "model.litertlm").takeIf { it.exists() }?.absolutePath
        buildUi()
        refreshModelStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(247, 245, 252))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Офлайн решатель"
            textSize = 28f
            setTextColor(Color.rgb(35, 30, 48))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Решай задания по фото прямо на телефоне"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(5), 0, dp(18))
        })

        modelButton = button("Выбрать файл нейросети (.litertlm)")
        modelButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, 102)
        }
        root.addView(modelButton)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(status)

        val choose = button("Выбрать фото задания")
        root.addView(choose)
        choose.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(intent, 101)
        }

        question = EditText(this).apply {
            hint = "Дополнительный вопрос (необязательно)"
            minLines = 2
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(question, matchWrap())

        val solve = button("Решить задание")
        solve.setOnClickListener { solvePhoto() }
        root.addView(solve, linearParams(top = 12))

        answer = TextView(this).apply {
            text = "Выбери файл модели и фотографию задания."
            textSize = 16f
            setTextColor(Color.rgb(35, 30, 48))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(answer, linearParams(top = 12))

        root.addView(TextView(this).apply {
            text = "Настройки памяти"
            textSize = 21f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(35, 30, 48))
            setPadding(0, dp(24), 0, dp(8))
        })

        memoryValue = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.rgb(35, 30, 48))
        }
        root.addView(memoryValue)

        memorySeek = SeekBar(this).apply {
            max = 9
            progress = ((memoryGb - 1.5) / 0.5).toInt().coerceIn(0, 9)
        }
        root.addView(memorySeek, matchWrap())
        updateMemoryLabel()
        memorySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                memoryGb = 1.5 + progress * 0.5
                updateMemoryLabel()
                if (fromUser) getPreferences(0).edit().putFloat("memory_gb", memoryGb.toFloat()).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        root.addView(TextView(this).apply {
            text = "Лимит 2,5 ГБ — целевой бюджет, а не жёсткое резервирование ОЗУ. Реальный расход зависит от модели и Android."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(14))
        })

        val unload = button("Остановить нейросеть и освободить ОЗУ")
        unload.setOnClickListener {
            executor.execute {
                try { conversation?.close() } catch (_: Throwable) {}
                try { engine?.close() } catch (_: Throwable) {}
                conversation = null
                engine = null
                runOnUiThread {
                    answer.text = "Нейросеть остановлена. Её ресурсы освобождены."
                    refreshModelStatus()
                }
            }
        }
        root.addView(unload)

        root.addView(TextView(this).apply {
            text = "После импорта модели приложение работает локально и не отправляет фотографии в интернет. Сначала нужно один раз получить модельный файл."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun refreshModelStatus() {
        val exists = modelPath?.let { File(it).exists() } == true
        status.text = if (exists) "Модель готова: ${File(modelPath!!).name}" else "Модель не выбрана. Нужен совместимый файл .litertlm."
    }

    private fun solvePhoto() {
        val uri = selectedImage
        val path = modelPath
        if (path == null || !File(path).exists()) {
            answer.text = "Сначала нажми «Выбрать файл нейросети» и выбери совместимый .litertlm."
            return
        }
        if (uri == null) {
            answer.text = "Сначала выбери фотографию задания."
            return
        }
        val prompt = question.text.toString().trim().ifBlank {
            "Реши задание на изображении на русском языке. Сначала перепиши условие, затем покажи решение по шагам и выдели итоговый ответ. Если часть изображения неразборчива, сообщи об этом и не выдумывай данные."
        }
        answer.text = "Загружаю модель и анализирую фото. Первый запуск может занять время…"
        executor.execute {
            try {
                if (engine == null) {
                    val newEngine = Engine(EngineConfig(
                        modelPath = path,
                        backend = Backend.CPU(),
                        cacheDir = cacheDir.absolutePath
                    ))
                    newEngine.initialize()
                    engine = newEngine
                    conversation = newEngine.createConversation()
                }
                val imageFile = copyUriToCache(uri)
                val result = conversation!!.sendMessage(
                    Contents.of(
                        Content.ImageFile(imageFile.absolutePath),
                        Content.Text(prompt)
                    )
                )
                runOnUiThread { answer.text = result.text.ifBlank { result.toString() } }
            } catch (t: Throwable) {
                runOnUiThread {
                    answer.text = "Не удалось запустить модель: ${t.message ?: t.javaClass.simpleName}\nПроверь, что выбран совместимый файл Gemma 3n LiteRT-LM и на телефоне достаточно свободной памяти."
                }
            }
        }
    }

    private fun copyUriToCache(uri: Uri): File {
        val out = File(cacheDir, "homework_image")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось прочитать фото" }
            FileOutputStream(out).use { output -> input.copyTo(output) }
        }
        return out
    }

    private fun importModel(uri: Uri) {
        answer.text = "Копирую файл модели во внутреннее хранилище приложения. Это может занять несколько минут…"
        executor.execute {
            try {
                val target = File(filesDir, "model.litertlm")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Не удалось открыть файл" }
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
                modelPath = target.absolutePath
                runOnUiThread {
                    answer.text = "Модель импортирована. Теперь можно выбрать фото задания."
                    refreshModelStatus()
                }
            } catch (t: Throwable) {
                runOnUiThread { answer.text = "Ошибка импорта модели: ${t.message}" }
            }
        }
    }

    private fun updateMemoryLabel() {
        memoryValue.text = "Лимит памяти: ${"%.1f".format(java.util.Locale.US, memoryGb)} ГБ" +
            if (memoryGb == 2.5) " (по умолчанию)" else ""
    }

    private fun button(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun linearParams(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    @Deprecated("Deprecated in Android, kept for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            selectedImage = data?.data
            answer.text = if (selectedImage != null) "Фото выбрано. Нажми «Решить задание»." else "Не удалось выбрать фото."
        } else if (requestCode == 102 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { importModel(it) }
        }
    }

    override fun onDestroy() {
        executor.execute {
            try { conversation?.close() } catch (_: Throwable) {}
            try { engine?.close() } catch (_: Throwable) {}
        }
        executor.shutdown()
        super.onDestroy()
    }
}
